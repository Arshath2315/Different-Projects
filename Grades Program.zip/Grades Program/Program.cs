﻿namespace Grades_Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int option = 1;
            string firstName = "", lastName = "";
            double midTermGrade = 0, finalExamGrade = 0, projectGrade = 0;
            const double weightMidTermGrade = 0.3, weightFinalExamGrade = 0.4, weightProjectGrade = 0.3;
            while (true)
            {
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine("Course Evaluation");
                Console.WriteLine("1. Enter one students data and grades");
                Console.WriteLine("2. Display the Grade Report for one student");
                Console.WriteLine("3. Exit the Application");
                Console.Write("Enter your Choice: ");
                option = Convert.ToInt32(Console.ReadLine());

            switch(option)
                {
                    case 1:
                        {
                            Console.WriteLine("\n1. Enter one students data and grades");
                            Console.Write("\nFirst Name: ");
                            firstName = Console.ReadLine();
                            Console.Write("Last Name: ");
                            lastName = Console.ReadLine();
                            Console.Write("Mid-Term Grade: ");
                            midTermGrade = Convert.ToDouble(Console.ReadLine());
                            Console.Write("Final Exam Grade: ");
                            finalExamGrade = Convert.ToDouble(Console.ReadLine());
                            Console.Write("Project Grade: ");
                           projectGrade = Convert.ToDouble(Console.ReadLine());

                            Console.WriteLine("Data has been Successfully inputed!");

                            break;
                        }

                    case 2:
                        {
                            Console.WriteLine("\n2. Display the Grade Report for one student");
                            Console.WriteLine("\nFirst Name: " + firstName);
                            Console.WriteLine("Last Name: " + lastName);
                            Console.WriteLine("Mid-Term Grade: " + midTermGrade);
                            Console.WriteLine("Final Exam Grade: " + finalExamGrade);
                            Console.WriteLine("Project Grade: " + projectGrade);

                            double finalGrade = (weightMidTermGrade * midTermGrade) + (weightFinalExamGrade * finalExamGrade) + (weightProjectGrade * projectGrade);

                            if (finalGrade >= 90) 
                            {
                                Console.WriteLine($"Final Grade: {finalGrade} = A"); 
                            }
                            else if (finalGrade >= 80) 
                            { 
                                Console.WriteLine($"Final Grade: {finalGrade} = B"); 
                            } 
                            else if (finalGrade >= 70) 
                            { 
                                Console.WriteLine($"Final Grade: {finalGrade} = C");
                            }
                            else if (finalGrade >= 60) 
                            { 
                                Console.WriteLine($"Final Grade: {finalGrade} = D");
                            }
                            else { 
                                Console.WriteLine($"Final Grade: {finalGrade} = F");
                            }

                            Console.ReadKey();

                            break;
                        }

                    case 3:
                        {
                            Console.Write("Hope This Helped!");
                            Environment.Exit(0);
                            Console.ReadKey();
                            break;
                        }

                }
                Console.WriteLine();
                Console.Write("Press any key");
                Console.ReadLine();
                Console.Clear();

            }

        }
    }
}