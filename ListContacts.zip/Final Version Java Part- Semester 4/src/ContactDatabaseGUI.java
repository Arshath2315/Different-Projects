import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.awt.Event;

public class ContactDatabaseGUI extends JFrame {
    private JComboBox<String> contactIdsComboBox;
    private JTextField firstNameTextField;
    private JTextField lastNameTextField;
    private JTextField ageTextField;
    private JTextField phoneTextField;
    private JButton addButton;
    private JButton updateButton;
    private JTextField searchTextField;
    private JButton searchButton;
    private JTable resultTable;
    private JButton eraseButton;

    // Constructor
    // Constructor
    public ContactDatabaseGUI() {
        setTitle("Contact DisplayGUI");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(500, 400);
        setLocationRelativeTo(null);

        //intializing components
        contactIdsComboBox = new JComboBox<>();
        firstNameTextField = new JTextField(10);
        lastNameTextField = new JTextField(10);
        ageTextField = new JTextField(10);
        phoneTextField = new JTextField(10);
        addButton = new JButton("Add");
        updateButton = new JButton("Update");
        searchTextField = new JTextField(15);
        searchButton = new JButton("Search");
        resultTable = new JTable(new DefaultTableModel());
        loadDataIntoTable();

        //Creates Layout
        JPanel topPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(5, 5, 5, 5);

        topPanel.add(new JLabel("Contact ID:"), gbc);
        gbc.gridx++;
        topPanel.add(contactIdsComboBox, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        topPanel.add(new JLabel("First Name:"), gbc);
        gbc.gridx++;
        topPanel.add(firstNameTextField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        topPanel.add(new JLabel("Last Name:"), gbc);
        gbc.gridx++;
        topPanel.add(lastNameTextField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        topPanel.add(new JLabel("Age:"), gbc);
        gbc.gridx++;
        topPanel.add(ageTextField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        topPanel.add(new JLabel("Phone:"), gbc);
        gbc.gridx++;
        topPanel.add(phoneTextField, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        topPanel.add(addButton, gbc);
        gbc.gridx++;
        topPanel.add(updateButton, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        topPanel.add(new JLabel("Search by First Name:"), gbc);
        gbc.gridx++;
        topPanel.add(searchTextField, gbc);
        gbc.gridx++;
        topPanel.add(searchButton, gbc);

        eraseButton = new JButton("Erase");
        gbc.gridx++;
        topPanel.add(eraseButton, gbc);

        eraseButton.addActionListener(e -> clearTextFields());

        add(topPanel, BorderLayout.NORTH);
        add(new JScrollPane(resultTable), BorderLayout.CENTER);

        loadContactIds();
        getContactData();

        addButton.addActionListener(e -> addRecord());
        updateButton.addActionListener(e -> updateRecord());
        searchButton.addActionListener(e -> searchContact());

        setVisible(true);
    }

    private void loadDataIntoTable() {
        try (Connection connection = DbConnection.connect()) {
            String query = "SELECT * FROM contact";
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(query)) {
                DefaultTableModel model = (DefaultTableModel) resultTable.getModel();
                model.setRowCount(0); // Clear previous data
                while (resultSet.next()) {
                    String id = resultSet.getString("id");
                    String firstName = resultSet.getString("firstName");
                    String lastName = resultSet.getString("lastName");
                    int age = resultSet.getInt("age");
                    String phone = resultSet.getString("phone");

                    model.addRow(new Object[]{id, firstName, lastName, age, phone});
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //Searches for contact through search button
    private void searchContact() {
        String name = searchTextField.getText().trim();
        if (!name.isEmpty()) {
            try (Connection connection = DbConnection.connect()) {
                String query = "SELECT * FROM contact WHERE firstName LIKE ?";
                try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                    preparedStatement.setString(1, "%" + name + "%");
                    try (ResultSet resultSet = preparedStatement.executeQuery()) {
                        if (resultSet.next()) {
                            String id = resultSet.getString("id");
                            String firstName = resultSet.getString("firstName");
                            String lastName = resultSet.getString("lastName");
                            int age = resultSet.getInt("age");
                            String phone = resultSet.getString("phone");

                            contactIdsComboBox.setSelectedItem(id);
                            firstNameTextField.setText(firstName);
                            lastNameTextField.setText(lastName);
                            ageTextField.setText(String.valueOf(age));
                            phoneTextField.setText(phone);

                            DefaultTableModel model = (DefaultTableModel) resultTable.getModel();
                            model.setRowCount(0);
                            do {
                                model.addRow(new Object[]{resultSet.getString("id"), resultSet.getString("firstName"),
                                        resultSet.getString("lastName"), resultSet.getInt("age"), resultSet.getString("phone")});
                            } while (resultSet.next());
                        } else {
                            clearTextFields();
                            JOptionPane.showMessageDialog(this, "No matching contact found.", "Information", JOptionPane.INFORMATION_MESSAGE);
                        }
                    }
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please enter a name to search.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
//    //DOESN'T WORK
//    private void searchContact() {
//        String name = searchTextField.getText().trim();
//        if (!name.isEmpty()) {
//            try (Connection connection = DbConnection.connect()) {
//                String query = "SELECT * FROM contact WHERE firstName LIKE ?";
//                try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
//                    preparedStatement.setString(1, "%" + name + "%");
//                    try (ResultSet resultSet = preparedStatement.executeQuery()) {
//                        DefaultTableModel model = (DefaultTableModel) resultTable.getModel();
//                        model.setRowCount(0); // Clear previous search results
//                        while (resultSet.next()) {
//                            String id = resultSet.getString("id");
//                            String firstName = resultSet.getString("firstName");
//                            String lastName = resultSet.getString("lastName");
//                            int age = resultSet.getInt("age");
//                            String phone = resultSet.getString("phone");
//
//                            model.addRow(new Object[]{id, firstName, lastName, age, phone});
//                        }
//                        if (model.getRowCount() == 0) {
//                            clearTextFields(); // Clear text fields if no results found
//                            JOptionPane.showMessageDialog(this, "No matching contact found.", "Information", JOptionPane.INFORMATION_MESSAGE);
//                        } else {
//                            // Display search results in a new window
//                            Object[][] searchData = new Object[model.getRowCount()][5];
//                            for (int i = 0; i < model.getRowCount(); i++) {
//                                for (int j = 0; j < 5; j++) {
//                                    searchData[i][j] = model.getValueAt(i, j);
//                                }
//                            }
//                            new SearchResultTable(searchData);
//                        }
//                    }
//                }
//            } catch (SQLException ex) {
//                ex.printStackTrace();
//            }
//        } else {
//            JOptionPane.showMessageDialog(this, "Please enter a name to search.", "Error", JOptionPane.ERROR_MESSAGE);
//        }
//    }

    private void clearTextFields() {
        contactIdsComboBox.setSelectedIndex(-1);
        firstNameTextField.setText("");
        lastNameTextField.setText("");
        ageTextField.setText("");
        phoneTextField.setText("");
    }

    private void loadContactIds() {
        try (Connection connection = DbConnection.connect()) {
            String query = "SELECT id FROM contact";
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(query)) {
                while (resultSet.next()) {
                    String id = resultSet.getString("id");
                    contactIdsComboBox.addItem(id);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void getContactData() {
        contactIdsComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedId = (String) contactIdsComboBox.getSelectedItem();
                if (selectedId != null) {
                    try (Connection connection = DbConnection.connect()) {
                        String query = "SELECT * FROM contact WHERE id = ?";
                        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                            preparedStatement.setString(1, selectedId);
                            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                                if (resultSet.next()) {
                                    String firstName = resultSet.getString("firstName");
                                    String lastName = resultSet.getString("lastName");
                                    int age = resultSet.getInt("age");
                                    String phone = resultSet.getString("phone");

                                    firstNameTextField.setText(firstName);
                                    lastNameTextField.setText(lastName);
                                    ageTextField.setText(String.valueOf(age));
                                    phoneTextField.setText(phone);
                                }
                            }
                        }
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });
    }

    private void addRecord() {
        String firstName = firstNameTextField.getText().trim();
        String lastName = lastNameTextField.getText().trim();
        String ageText = ageTextField.getText().trim();
        String phone = phoneTextField.getText().trim();

        if (firstName.isEmpty() || lastName.isEmpty() || ageText.isEmpty() || phone.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int age;
        try {
            age = Integer.parseInt(ageText);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid age.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (contactExists(firstName, lastName, phone)) {
            JOptionPane.showMessageDialog(this, "Contact already exists in the database.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection connection = DbConnection.connect()) {
            String query = "INSERT INTO contact (firstName, lastName, age, phone) VALUES (?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, firstName);
                preparedStatement.setString(2, lastName);
                preparedStatement.setInt(3, age);
                preparedStatement.setString(4, phone);
                int rowsInserted = preparedStatement.executeUpdate();
                if (rowsInserted > 0) {
                    JOptionPane.showMessageDialog(this, "Contact added successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                    contactIdsComboBox.removeAllItems();
                    loadContactIds();
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to add contact.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean contactExists(String firstName, String lastName, String phone) {
        try (Connection connection = DbConnection.connect()) {
            String query = "SELECT COUNT(*) AS count FROM contact WHERE firstName = ? AND lastName = ? AND phone = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, firstName);
                preparedStatement.setString(2, lastName);
                preparedStatement.setString(3, phone);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        int count = resultSet.getInt("count");
                        return count > 0;
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }

    private void updateRecord() {
        String id = (String) contactIdsComboBox.getSelectedItem();
        String firstName = firstNameTextField.getText().trim();
        String lastName = lastNameTextField.getText().trim();
        String ageText = ageTextField.getText().trim();
        String phone = phoneTextField.getText().trim();

        if (id == null || firstName.isEmpty() || lastName.isEmpty() || ageText.isEmpty() || phone.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please select a contact and fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int age;
        try {
            age = Integer.parseInt(ageText);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid age.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection connection = DbConnection.connect()) {
            String query = "UPDATE contact SET firstName = ?, lastName = ?, age = ?, phone = ? WHERE id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, firstName);
                preparedStatement.setString(2, lastName);
                preparedStatement.setInt(3, age);
                preparedStatement.setString(4, phone);
                preparedStatement.setString(5, id);
                int rowsUpdated = preparedStatement.executeUpdate();
                if (rowsUpdated > 0) {
                    JOptionPane.showMessageDialog(this, "Contact updated successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to update contact.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
