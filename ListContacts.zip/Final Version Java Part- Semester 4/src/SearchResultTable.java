//import javax.swing.*;
//import javax.swing.table.DefaultTableModel;
//import java.awt.*;
//DOESN'T WORK NOT DISPLAYING JTable
//
//public class SearchResultTable extends JFrame {
//    private JTable resultTable;
//
//    public SearchResultTable(Object[][] data) {
//        setTitle("Search Results");
//        setSize(500, 400);
//        setLocationRelativeTo(null);
//
//        resultTable = new JTable(new DefaultTableModel(data, new Object[]{"ID", "First Name", "Last Name", "Age", "Phone"}));
//
//        add(new JScrollPane(resultTable), BorderLayout.CENTER);
//
//        setVisible(true);
//    }
//}
